from flask import Flask, render_template, request, redirect, url_for, flash, session
import os
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# إعداد مجلد الصور
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# قاعدة بيانات المستخدمين (مؤقتة)
users_db = []

# قائمة المنتجات
products = [
    {"name": "دواء للزكام", "image": "images/flu.jpg", "discount": 0},
    {"name": "دواء للسعال", "image": "images/cough.jpg", "discount": 0},
    {"name": "دواء للصداع", "image": "images/headache.jpg", "discount": 0},
    {"name": "فيتامينات", "image": "images/vita.jpg", "discount": 0},
    {"name": "مرهم للعضلات", "image": "images/muscles.jpg", "discount": 0},
    {"name": "مكمل غذائي", "image": "images/mokamel.jpg", "discount": 0},
]

# صفحة التسجيل
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']

        # التحقق من وجود المستخدم مسبقًا
        for user in users_db:
            if user['email'] == email:
                flash('البريد الإلكتروني موجود بالفعل', 'danger')
                return redirect(url_for('signup'))

        # إضافة المستخدم
        hashed_password = generate_password_hash(password)
        users_db.append({'email': email, 'password': hashed_password, 'role': role, 'points': 0, 'last_donated_medicine': None})
        flash('تم إنشاء الحساب بنجاح', 'success')
        return redirect(url_for('login'))  # التوجيه إلى صفحة تسجيل الدخول

    return render_template('signup.html')


# صفحة تسجيل الدخول
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']

        # التحقق من صحة بيانات المستخدم
        user = next((u for u in users_db if u['email'] == email), None)
        if user and check_password_hash(user['password'], password) and user['role'] == role:
            session['user_email'] = user['email']
            session['user_role'] = user['role']
            session['user_points'] = user['points']  # Store user points in session
            session['user_last_donated_medicine'] = user['last_donated_medicine']  # Store last donated medicine

            flash('تم تسجيل الدخول بنجاح', 'success')

            # التوجيه بناءً على الدور
            if role == 'donator':
                return redirect(url_for('index'))
            elif role == 'patient':
                return redirect(url_for('search'))

        flash('بيانات الدخول غير صحيحة', 'danger')
        return redirect(url_for('login'))

    return render_template('login.html')


# صفحة التبرع
@app.route('/')
@app.route('/index')
def index():
    # Ensure the user is logged in and retrieve their points and last donated medicine
    if 'user_email' not in session:
        return redirect(url_for('login'))

    user_points = session['user_points']
    last_donated_medicine = session['user_last_donated_medicine']

    # تحديث الخصومات بناءً على النقاط
    for product in products:
        product["discount"] = (user_points // 100) * 5  # خصم 5% لكل 100 نقطة

    return render_template('index.html', points=user_points, products=products, last_donated_medicine=last_donated_medicine)


@app.route('/donate', methods=['POST'])
def donate():
    if 'user_email' not in session:
        return redirect(url_for('login'))

    medicine_name = request.form['medicine_name']
    medicine_image = request.files['medicine_image']

    # Save the medicine image
    if medicine_image:
        filename = secure_filename(medicine_image.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        medicine_image.save(filepath)

        # Update the last donated medicine
        session['user_last_donated_medicine'] = filename

    # Add points to the user
    session['user_points'] += 100

    # Update the points in the user database
    user = next(u for u in users_db if u['email'] == session['user_email'])
    user['points'] = session['user_points']
    user['last_donated_medicine'] = session['user_last_donated_medicine']

    return redirect(url_for('index'))


# صفحة البحث
@app.route('/search')
def search():
    if 'user_email' not in session:
        return redirect(url_for('login'))

    return render_template('search.html')


if __name__ == '__main__':
    app.run(debug=True, port=5001)
