import sqlite3

# إنشاء اتصال بقاعدة البيانات
conn = sqlite3.connect('donation.db')
cursor = conn.cursor()

# إنشاء جدول للأدوية المتبرع بها
cursor.execute('''
CREATE TABLE IF NOT EXISTS donated_medicines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    image TEXT NOT NULL,
    donator_email TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')

# حفظ التغييرات وإغلاق الاتصال
conn.commit()
conn.close()

print("تم إنشاء قاعدة البيانات والجدول بنجاح!")
