# Pharmacy Management System

A modern Flask-based web application for managing a pharmacy's medication inventory and prescriptions.

## Features

- User Authentication (Register/Login)
- Admin Dashboard for Medication Management
- Medication Search and Filtering
- Prescription Upload System
- Responsive Design for Mobile and Desktop
- Modern UI with Material Design Influences

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- SQLite3

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd pharmacy-app
```

2. Create a virtual environment and activate it:
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/macOS
python3 -m venv venv
source venv/bin/activate
```

3. Install the required packages:
```bash
pip install -r requirements.txt
```

4. Initialize the database:
```bash
python
>>> from app import db, init_db
>>> init_db()
>>> exit()
```

## Running the Application

1. Start the Flask development server:
```bash
python app.py
```

2. Open your web browser and navigate to:
```
http://localhost:5000
```

## Default Admin Account

The application comes with a default admin account:
- Username: `admin`
- Password: `admin`

**Important**: Change these credentials in a production environment.

## Project Structure

```
pharmacy-app/
├── app.py                 # Main application file
├── requirements.txt       # Python dependencies
├── static/               # Static files
│   ├── css/             # CSS stylesheets
│   ├── js/              # JavaScript files
│   └── images/          # Image assets
└── templates/           # HTML templates
    ├── base.html        # Base template
    ├── index.html       # Landing page
    ├── login.html       # User login
    ├── register.html    # User registration
    ├── dashboard.html   # User dashboard
    ├── upload.html      # Prescription upload
    ├── admin_login.html # Admin login
    └── admin.html       # Admin dashboard
```

## Security Features

- Password hashing using Werkzeug Security
- CSRF protection
- Secure session management
- Input validation and sanitization

## Contributing

1. Fork the repository
2. Create a new branch for your feature
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Flask framework
- Bootstrap for UI components
- Font Awesome for icons 