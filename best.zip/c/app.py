from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os
from functools import wraps
import requests
from scraper import search_drugs

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///pharmacy.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

# Create uploads directory if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

db = SQLAlchemy(app)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login first.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            flash('Please login as admin.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Database Models
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    first_name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class Medication(db.Model):
    __tablename__ = 'medications'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    allergy_test_required = db.Column(db.Boolean, default=False)
    storage_instructions = db.Column(db.Text)
    category = db.Column(db.String(50), nullable=False, default='antibiotics')

class Admin(db.Model):
    __tablename__ = 'admins'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class Prescription(db.Model):
    __tablename__ = 'prescriptions'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    admin_notes = db.Column(db.Text)
    review_date = db.Column(db.DateTime)

    user = db.relationship('User', backref=db.backref('prescriptions', lazy=True))

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # First check if it's an admin
        admin = Admin.query.filter_by(username=username).first()
        if admin and check_password_hash(admin.password, password):
            session['admin_id'] = admin.id
            session['is_admin'] = True
            flash('Welcome back, Admin!', 'success')
            return redirect(url_for('admin_dashboard'))
        
        # If not admin, check if it's a regular user
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['first_name'] = user.first_name
            flash(f'Welcome back, {user.first_name}!', 'success')
            return redirect(url_for('dashboard'))
            
        flash('Invalid username or password', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('register'))
            
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('register'))
            
        hashed_password = generate_password_hash(password)
        new_user = User(username=username, first_name=first_name, last_name=last_name,
                       email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    medications = Medication.query.all()
    return render_template('dashboard.html', user=user, medications=medications)

@app.route('/admin')
@admin_required
def admin_dashboard():
    medications = Medication.query.all()
    return render_template('admin_dashboard.html', medications=medications)

@app.route('/admin/medications/add', methods=['POST'])
@admin_required
def add_medication():
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            price = float(request.form.get('price'))
            allergy_test_required = bool(request.form.get('allergy_test_required'))
            storage_instructions = request.form.get('storage_instructions')
            category = request.form.get('category', 'antibiotics')
            
            medication = Medication(
                name=name,
                price=price,
                allergy_test_required=allergy_test_required,
                storage_instructions=storage_instructions,
                category=category
            )
            db.session.add(medication)
            db.session.commit()
            
            flash('Medication added successfully!', 'success')
        except Exception as e:
            flash('Error adding medication: ' + str(e), 'error')
        
        return redirect(url_for('admin_dashboard'))

@app.route('/admin/medications/edit/<int:id>', methods=['POST'])
@admin_required
def edit_medication(id):
    medication = Medication.query.get_or_404(id)
    if request.method == 'POST':
        try:
            medication.name = request.form.get('name')
            medication.price = float(request.form.get('price'))
            medication.allergy_test_required = bool(request.form.get('allergy_test_required'))
            medication.storage_instructions = request.form.get('storage_instructions')
            medication.category = request.form.get('category', 'antibiotics')
            
            db.session.commit()
            flash('Medication updated successfully!', 'success')
        except Exception as e:
            flash('Error updating medication: ' + str(e), 'error')
        
        return redirect(url_for('admin_dashboard'))

@app.route('/admin/medications/delete/<int:id>')
@admin_required
def delete_medication(id):
    try:
        medication = Medication.query.get_or_404(id)
        db.session.delete(medication)
        db.session.commit()
        flash('Medication deleted successfully!', 'success')
    except Exception as e:
        flash('Error deleting medication: ' + str(e), 'error')
    
    return redirect(url_for('admin_dashboard'))

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        if 'prescription' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
            
        file = request.files['prescription']
        message = request.form.get('message', '')
        
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
            
        if file and allowed_file(file.filename):
            # Secure the filename and generate unique name
            original_filename = secure_filename(file.filename)
            filename = f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{original_filename}"
            
            # Save the file
            try:
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                
                # Create prescription record
                prescription = Prescription(
                    user_id=session['user_id'],
                    filename=filename,
                    original_filename=original_filename,
                    message=message
                )
                
                db.session.add(prescription)
                db.session.commit()
                
                flash('Prescription uploaded successfully!', 'success')
                return redirect(url_for('dashboard'))
            except Exception as e:
                flash(f'Error uploading file: {str(e)}', 'error')
                return redirect(request.url)
        else:
            flash('Invalid file type. Allowed types: PDF, PNG, JPG, JPEG', 'error')
            
    # Get user's prescriptions for display
    user_prescriptions = Prescription.query.filter_by(user_id=session['user_id']).order_by(Prescription.upload_date.desc()).all()
    return render_template('upload.html', prescriptions=user_prescriptions)

@app.route('/download/<int:prescription_id>')
def download_prescription(prescription_id):
    # Check if user is logged in (either as admin or regular user)
    if not session.get('user_id') and not session.get('admin_id'):
        flash('Please login first.', 'error')
        return redirect(url_for('login'))

    prescription = Prescription.query.get_or_404(prescription_id)
    
    # Security check: ensure user can only download their own prescriptions or is admin
    if not session.get('is_admin') and prescription.user_id != session.get('user_id'):
        flash('Unauthorized access', 'error')
        return redirect(url_for('dashboard'))
        
    try:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], prescription.filename)
        if not os.path.exists(file_path):
            flash('File not found', 'error')
            return redirect(url_for('admin_prescriptions') if session.get('is_admin') else url_for('dashboard'))
            
        directory = os.path.dirname(file_path)
        filename = os.path.basename(file_path)
        
        return send_from_directory(
            directory=directory,
            path=filename,
            as_attachment=True,
            download_name=prescription.original_filename
        )
    except Exception as e:
        flash(f'Error downloading file: {str(e)}', 'error')
        return redirect(url_for('admin_prescriptions') if session.get('is_admin') else url_for('dashboard'))

@app.route('/uploads/<path:filename>')
def serve_upload(filename):
    # Check if user is logged in (either as admin or regular user)
    if not session.get('user_id') and not session.get('admin_id'):
        flash('Please login first.', 'error')
        return redirect(url_for('login'))
        
    try:
        return send_from_directory(
            app.config['UPLOAD_FOLDER'],
            filename,
            as_attachment=False
        )
    except Exception as e:
        return f'Error serving file: {str(e)}', 404

@app.route('/delete_prescription/<int:prescription_id>')
@login_required
def delete_prescription(prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    
    # Security check: ensure user can only delete their own prescriptions
    if prescription.user_id != session['user_id'] and 'admin_id' not in session:
        flash('Unauthorized access', 'error')
        return redirect(url_for('dashboard'))
    
    try:
        # Delete file from filesystem
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], prescription.filename)
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Delete database record
        db.session.delete(prescription)
        db.session.commit()
        
        flash('Prescription deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting prescription: {str(e)}', 'error')
    
    return redirect(url_for('upload'))

@app.route('/admin/prescriptions')
@admin_required
def admin_prescriptions():
    prescriptions = Prescription.query.order_by(Prescription.upload_date.desc()).all()
    return render_template('admin_prescriptions.html', prescriptions=prescriptions)

@app.route('/admin/prescriptions/review/<int:prescription_id>')
@admin_required
def review_prescription(prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    return render_template('review_prescription.html', prescription=prescription)

@app.route('/admin/prescriptions/update_status/<int:prescription_id>', methods=['POST'])
@admin_required
def update_prescription_status(prescription_id):
    prescription = Prescription.query.get_or_404(prescription_id)
    new_status = request.form.get('status')
    admin_notes = request.form.get('admin_notes', '')
    
    prescription.status = new_status
    prescription.admin_notes = admin_notes
    prescription.review_date = datetime.utcnow()
    
    db.session.commit()
    flash('Prescription review saved successfully!', 'success')
    return redirect(url_for('admin_prescriptions'))

@app.route('/pharmacy-finder')
@login_required
def pharmacy_finder():
    return render_template('pharmacy_finder.html')

@app.route('/find-nearest-pharmacy')
@login_required
def find_nearest_pharmacy():
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    
    if not latitude or not longitude:
        return jsonify({
            'pharmacy_name': 'Error',
            'pharmacy_address': 'Location coordinates not provided'
        })

    url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
    params = {
        "location": f"{latitude},{longitude}",
        "radius": 5000,
        "type": "pharmacy",
        "key": "AIzaSyBbe9C8ZvYsA8VNzREojBjmgo7Apaf2R20"
    }
    
    try:
        response = requests.get(url, params=params)
        data = response.json()
        
        if data.get("results"):
            nearest_pharmacy = data["results"][0]
            return jsonify({
                'pharmacy_name': nearest_pharmacy["name"],
                'pharmacy_address': nearest_pharmacy.get("vicinity", "Address not available"),
                'pharmacy_lat': nearest_pharmacy["geometry"]["location"]["lat"],
                'pharmacy_lng': nearest_pharmacy["geometry"]["location"]["lng"]
            })
        else:
            return jsonify({
                'pharmacy_name': "No pharmacies found nearby",
                'pharmacy_address': ""
            })
            
    except Exception as e:
        return jsonify({
            'pharmacy_name': 'Error',
            'pharmacy_address': str(e)
        })

@app.route('/search')
def search_page():
    return render_template('search_drugs.html')

@app.route('/api/search_drugs')
def search_drug():
    query = request.args.get('query')
    if not query:
        return jsonify({'error': 'No query provided'}), 400

    results = search_drugs(query)
    return jsonify(results)

def init_db():
    with app.app_context():
        db.create_all()
        # Create default admin account if it doesn't exist
        if not Admin.query.filter_by(username='admin').first():
            admin = Admin(
                username='admin',
                password=generate_password_hash('admin')
            )
            db.session.add(admin)
            db.session.commit()
            print("Default admin account created - username: admin, password: admin")

if __name__ == '__main__':
    init_db()
    app.run(debug=True)