from app import app, db, Medication, Prescription
from sqlalchemy import text

def migrate_db():
    with app.app_context():
        # Drop existing tables
        try:
            with db.engine.connect() as conn:
                conn.execute(text("DROP TABLE IF EXISTS medications"))
                conn.execute(text("DROP TABLE IF EXISTS prescriptions"))
                conn.commit()
            print("Dropped existing tables")
        except Exception as e:
            print("Error dropping tables:", str(e))
        
        # Create all tables with latest schema
        db.create_all()
        print("Created tables with updated schema")
        
        # Add sample medications
        try:
            sample_medications = [
                # Antibiotics
                Medication(
                    name="Augmentin",
                    price=65.00,
                    allergy_test_required=True,
                    storage_instructions="Store at room temperature between 15-25°C",
                    category="antibiotics"
                ),
                Medication(
                    name="Ceftriaxone",
                    price=45.00,
                    allergy_test_required=True,
                    storage_instructions="Store in a dry place below 30°C",
                    category="antibiotics"
                ),
                Medication(
                    name="Zithromax",
                    price=85.00,
                    allergy_test_required=True,
                    storage_instructions="Store at room temperature, protect from light",
                    category="antibiotics"
                ),
                Medication(
                    name="Ciprofloxacin",
                    price=35.00,
                    allergy_test_required=True,
                    storage_instructions="Store at room temperature between 15-30°C",
                    category="antibiotics"
                ),

                # Local Anesthetics
                Medication(
                    name="Mepivacaine",
                    price=120.00,
                    allergy_test_required=True,
                    storage_instructions="Store at controlled room temperature 20-25°C",
                    category="anesthetics"
                ),
                Medication(
                    name="Marcaine",
                    price=150.00,
                    allergy_test_required=True,
                    storage_instructions="Store at room temperature, protect from light",
                    category="anesthetics"
                ),
                Medication(
                    name="Xylocaine",
                    price=90.00,
                    allergy_test_required=True,
                    storage_instructions="Store below 25°C, do not freeze",
                    category="anesthetics"
                ),
                Medication(
                    name="Septodont",
                    price=110.00,
                    allergy_test_required=True,
                    storage_instructions="Store between 15-30°C",
                    category="anesthetics"
                ),

                # Chemotherapy
                Medication(
                    name="Adriamycin",
                    price=1200.00,
                    allergy_test_required=True,
                    storage_instructions="Store in refrigerator 2-8°C, protect from light",
                    category="chemotherapy"
                ),
                Medication(
                    name="Carboplatin",
                    price=950.00,
                    allergy_test_required=True,
                    storage_instructions="Store at controlled room temperature 20-25°C",
                    category="chemotherapy"
                ),
                Medication(
                    name="Methotrexate",
                    price=750.00,
                    allergy_test_required=True,
                    storage_instructions="Store at room temperature, protect from light",
                    category="chemotherapy"
                ),
                Medication(
                    name="Taxol",
                    price=2200.00,
                    allergy_test_required=True,
                    storage_instructions="Store in refrigerator 2-8°C",
                    category="chemotherapy"
                ),

                # Biologics
                Medication(
                    name="Herceptin",
                    price=4500.00,
                    allergy_test_required=True,
                    storage_instructions="Store in refrigerator 2-8°C, do not freeze",
                    category="biologics"
                ),
                Medication(
                    name="Remicade",
                    price=3800.00,
                    allergy_test_required=True,
                    storage_instructions="Store in refrigerator 2-8°C, protect from light",
                    category="biologics"
                ),
                Medication(
                    name="Enbrel",
                    price=2900.00,
                    allergy_test_required=True,
                    storage_instructions="Store in refrigerator 2-8°C",
                    category="biologics"
                ),
                Medication(
                    name="Rituximab",
                    price=5200.00,
                    allergy_test_required=True,
                    storage_instructions="Store in refrigerator 2-8°C, protect from light",
                    category="biologics"
                )
            ]
            
            db.session.add_all(sample_medications)
            db.session.commit()
            print("Added sample medications")
        except Exception as e:
            print("Error adding sample medications:", str(e))

if __name__ == '__main__':
    migrate_db() 