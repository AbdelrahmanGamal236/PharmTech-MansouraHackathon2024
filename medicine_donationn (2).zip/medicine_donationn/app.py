from flask import Flask, render_template, request, redirect, url_for, session
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

# إعداد مجلد الصور
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'your_secret_key'  # Add a secret key for sessions
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# نقاط المستخدم
user_points = 0

# قائمة المنتجات
products = [
    {"name": "دواء للزكام", "image": "images/flu.jpg", "discount": 0},
    {"name": "دواء للسعال", "image": "images/cough.jpg", "discount": 0},
    {"name": "دواء للصداع", "image": "images/headache.jpg", "discount": 0},
    {"name": "فيتامينات", "image": "images/vita.jpg", "discount": 0},
    {"name": "مرهم للعضلات", "image": "images/muscles.jpg", "discount": 0},
    {"name": "مكمل غذائي", "image": "images/mokamel.jpg", "discount": 0},
]

# متغير لتخزين اسم صورة الدواء المتبرع به
last_donated_medicine = None

@app.route('/')
def index():
    global last_donated_medicine

    # تحديث الخصومات بناءً على النقاط
    for product in products:
        product["discount"] = (user_points // 100) * 5  # خصم 5% لكل 100 نقطة

    return render_template('index.html', points=user_points, products=products, last_donated_medicine=last_donated_medicine)

@app.route('/donate', methods=['POST'])
def donate():
    global user_points, last_donated_medicine

    # معالجة البيانات
    medicine_name = request.form['medicine_name']
    medicine_image = request.files['medicine_image']

    # حفظ صورة الدواء
    if medicine_image:
        filename = secure_filename(medicine_image.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        medicine_image.save(filepath)

        # تخزين اسم الصورة ليتم عرضها بعد التبرع
        last_donated_medicine = filename

    # إضافة النقاط
    user_points += 100

    return redirect(url_for('index'))

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    # Get product data from the form
    product_name = request.form['product_name']
    product_image = request.form['product_image']
    product_discount = request.form['product_discount']

    # Initialize cart if not already present in session
    if 'cart' not in session:
        session['cart'] = []

    # Add the product to the cart
    session['cart'].append({
        'name': product_name,
        'image': product_image,
        'discount': product_discount
    })

    # Commit the session changes
    session.modified = True

    # After adding the product, redirect to the cart page
    return redirect(url_for('cart'))

@app.route('/cart')
def cart():
    # Retrieve cart items from the session
    cart_items = session.get('cart', [])
    return render_template('cart.html', cart_items=cart_items)

if __name__ == '__main__':
    app.run(debug=True)
