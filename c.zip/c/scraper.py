import requests


# Copied functions from price_api.services.scraper

def filter_result(query: str, products: list[dict]):
    return [item for item in products if query.lower() in item['name'].lower()]


def search_tarshouby(query: str):
    """Fetch product data from Tarshouby API and insert into DB."""
    headers = {
        "Authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL21hc3RlcmFwaS53aXRoZWxkb2thbi5jb20vYXBpL2N1c3RvbWVyL2hvbWUvaW5pdGlhbGl6ZSIsImlhdCI6MTczMDczODE4MCwiZXhwIjozNzczMDczODE4MCwibmJmIjoxNzMwNzM4MTgwLCJqdGkiOiJJZUx3V1hqSzhrSWx2dDRvIiwic3ViIjo3ODg4OTg3LCJwcnYiOiI0YWMwNWMwZjhhYzA4ZjM2NGNiNGQwM2ZiOGUxZjYzMWZlYzMyMmU4In0.ugrjOkBTsyUF3xD7K75FnCu4NroaGrCL1ZE2-Yi1LwU",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Referer": "https://alabdellatif-tarshouby.com/",
    }
    payload = {
        'q': query.strip(' '),
        'search': query.strip(' '),
    }

    url = "https://masterapi.witheldokan.com/api/customer/products/search?"
    response = requests.post(url, headers=headers, params=payload)
    json_response = response.json()

    if json_response['code'] == 200:
        data = json_response['data']['products']
        products_data = [{
            'platform_id': item['id'],
            'name': item['name_en'],
            'name_en': item['name_en'],
            'name_ar': item['name_ar'],
            'category': item['category'],
            'stock': item['stock'],
            'price': item['price'],
            'share_link': item['share_link'],
            'image': item['image'],
            'source': 'tarshouby'
        } for item in data]
        return products_data
    else:
        logger.error(f"Error fetching result for query {query}: {json_response['code']}")
        return None


# Copied function from drug_storage.main

def fetch_drug_data(drug_name: str) -> str:
    """Fetch drug data from OpenFDA API."""
    # Base URL for OpenFDA API
    base_url = f"https://api.fda.gov/drug/label.json?search=openfda.brand_name:{drug_name}"
    response = requests.get(base_url)

    if response.status_code == 200:
        data = response.json()
        if 'results' in data:
            try:
                # Fetch storage information
                storage_info = data['results'][0].get('storage_and_handling', 'لا توجد معلومات تخزين متاحة.')

                # Default allergy info message
                allergy_info = "لا يتطلب اختبار حساسية."  # Default assumption

                # Check for allergy-related warnings or side effects
                warnings = str(data['results'][0].get('warnings', ''))
                adverse_reactions = str(data['results'][0].get('adverse_reactions', ''))

                # Check for specific keywords related to allergies
                if 'allergic reactions' in warnings.lower() or 'hypersensitivity' in adverse_reactions.lower():
                    allergy_info = "هذا الدواء قد يتطلب اختبار حساسية."

                # Explicitly set allergy_info to "No allergy test needed" for known drugs like Panadol
                if 'panadol' in drug_name.lower():
                    allergy_info = "لا يتطلب اختبار حساسية."

                return f"شروط التخزين: {storage_info}\nهل يحتاج إلى اختبار حساسية؟ {allergy_info}"
            except KeyError:
                return "لا توجد معلومات متاحة لهذا الدواء."
        else:
            return "الدواء غير موجود في قاعدة بيانات OpenFDA."
    else:
        return f"حدث خطأ: {response.status_code}"


def search_drugs(query: str):
    # Use the existing functions to search for drugs
    tarshouby_results = search_tarshouby(query)
    filtered_results = filter_result(query, tarshouby_results)
    
    # Fetch additional drug data for each drug name in the results
    detailed_drug_data = []
    for item in filtered_results:
        drug_data = fetch_drug_data(item['name'])
        detailed_drug_data.append({
            'name': item['name'],
            'price': item['price'],
            'drug_data': drug_data
        })

    # Combine results
    return {
        "detailed_results": detailed_drug_data
    }
